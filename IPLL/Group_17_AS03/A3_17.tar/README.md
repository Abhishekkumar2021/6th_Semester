# Group 17 - IPLL
## Members
- Abhishek Kumar ( 200101006 )
- Amjed Parvaiz ( 200101014 )

## Steps to run the code - 
- Run makefile using command
```bash
make
```
