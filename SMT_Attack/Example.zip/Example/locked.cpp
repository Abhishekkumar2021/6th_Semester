#include<bits/stdc++.h>
using namespace std;

int main(int argc, char *argv[]){
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    int out;
    int k1, k2;
    bool k3;
    if((a > b)^k3)
        out = a + k1;
    else
        out = b*k2;
    return 0;
}